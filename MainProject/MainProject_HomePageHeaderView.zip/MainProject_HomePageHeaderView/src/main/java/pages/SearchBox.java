package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import utilities.Base;
import utilities.ScreenShots;

public class SearchBox extends Base{

	By header = By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[2]/ul/li/button");
	By searchBox=By.xpath("//*[@id=\"workspace-filter-983466\"]");
    By wrkspacelist=By.className("workspacelink");
    By firstwrkCount=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[1]/div/div/div/div/div[2]/div/nav/div[1]/div[1]/span[2]");
    By secondwrkCount=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[1]/div/div/div/div/div[2]/div/nav/div[2]/div[1]/span[2]");
    By thirdwrkCount=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[1]/div/div/div/div/div[2]/div/nav/div[3]/div[1]/span[2]");
    By wrktitle=By.xpath("//*[@id=\"983466WorkspaceCollapseMenu\"]/div/div/div/div[2]/div/nav/div/div[2]");
   // By aboutCognizantdetail = By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[1]/div/div/div/div/div[2]/div/nav/div[1]/div[3]/div/div[1]/ul/li/a");
	By Strategydetail = By.xpath("//*[@id=\"mCSB_6_container\"]/ul/li[1]/a");
	//By Inclusivedetail = By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[1]/div/div/div/div/div[2]/div/nav/div[3]/div[3]/div/div[1]/ul/li/a");
	int temp=0;
	
	public void searchBox(String heading, String elementTobeSearched) {
		ScreenShots s=new ScreenShots(driver);
		boolean flag=driver.findElement(searchBox).isEnabled();
		if(flag==true){
			reportPass("SearchBox Enabled");
		}
		else{
			reportFail("SearchBox not Enabled");
		}
		String placeholdervalue=driver.findElement(searchBox).getAttribute("placeholder");
		System.out.println("Placeholder value: "+placeholdervalue);
		List<WebElement> headers = driver.findElements(header);
		List<WebElement> workspacelists = driver.findElements(wrkspacelist);
		for (WebElement head : headers) {
			 
			if(head.getText().contentEquals(heading))
			{
				head.click();
				wait(20,searchBox);
				driver.findElement(searchBox).sendKeys(elementTobeSearched,Keys.ENTER);
				s.captureScreenShot();
				for(WebElement l:workspacelists){
					 if(l.getText().contentEquals(elementTobeSearched)){
						    reportPass(elementTobeSearched+" is found");
					    	System.out.println(elementTobeSearched+" is found");
					    	break;
					 }
				}
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				List<WebElement> titles = driver.findElements(wrktitle);
				for (WebElement tit : titles) {
					//System.out.println(tit.getText());
					/*if (tit.getText().isEmpty()) {
						System.out.println("Helllooo");
						break;
					} else {*/
						System.out.println("\n" + tit.getText());
						if (tit.getText().contentEquals("About Cognizant")) {
							
							String actualcount = driver.findElement(firstwrkCount).getText();
							System.out.println("Count:"+actualcount);
							int acount = Integer.parseInt(actualcount);
							if (acount == 0) {
								reportPass("About Cognizant Count verified");
								System.out.println("Matched");
							} else {
								reportFail("About Cognizant count is not correct");
								System.out.println("Mismatched");
							}
						} if (tit.getText().contentEquals("Strategy and Latest Thinking")) {
							List<WebElement> details = driver.findElements(Strategydetail);
							int count = 0;
							count = details.size();
							for (WebElement d : details) {
								System.out.println(d.getText());
							}
							String actualcount = driver.findElement(secondwrkCount).getText();
							System.out.println("Count:"+actualcount);
							int acount = Integer.parseInt(actualcount);
							if (acount == count) {
								reportPass("Strategy and Latest Thinking Count verified");
								System.out.println("Matched");
							} else {
								reportFail("Strategy and Latest Thinking count is not correct");
								System.out.println("Mismatched");
							}
						} if (tit.getText().contentEquals("Inclusion and Values")) {
							
							String actualcount = driver.findElement(thirdwrkCount).getText();
							System.out.println("Count:"+actualcount);
							int acount = Integer.parseInt(actualcount);
							if (acount == 0) {
								reportPass("Inclusion and Values Count verified");
								System.out.println("Matched");
							} else {
								reportFail("Inclusion and Values count is not correct");
								System.out.println("Mismatched");
							}
						}

			}
		}
	}
}
}
