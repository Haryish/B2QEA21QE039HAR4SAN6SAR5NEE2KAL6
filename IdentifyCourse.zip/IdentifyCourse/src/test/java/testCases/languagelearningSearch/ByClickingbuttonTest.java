package testCases.languagelearningSearch;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.languagelearningSearch;
import utilities.DriverSetup;
import utilities.ExtentReportManager;


public class ByClickingbuttonTest extends DriverSetup{

	languagelearningSearch LanguagelearningSearch;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;

	
	public ByClickingbuttonTest() {

		super();
	}

	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		LanguagelearningSearch = new languagelearningSearch();
		LanguagelearningSearch.SearchBox();
	}

	@Test
	public void checksearchbuttonText() {
		
		logger = report.createTest("checks search button");

		LanguagelearningSearch.SearchBox();
		String expected=driver.findElement(By.xpath("//*[@id=\"rendered-content\"]/div/header/div/div/div/div[1]/div[3]/div/form/div/div/div[1]/div[1]/input")).getAttribute("placeholder");
		Assert.assertEquals(expected, "What do you want to learn?");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}
	
	
	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}
}
