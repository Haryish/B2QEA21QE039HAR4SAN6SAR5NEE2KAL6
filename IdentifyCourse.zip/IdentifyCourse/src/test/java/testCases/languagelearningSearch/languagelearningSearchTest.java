package testCases.languagelearningSearch;


import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.languagelearningSearch;
import utilities.DriverSetup;
import utilities.ExtentReportManager;


public class languagelearningSearchTest extends DriverSetup {

	languagelearningSearch LanguagelearningSearch;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;

	public languagelearningSearchTest() {

		super();
	}

	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		LanguagelearningSearch = new languagelearningSearch();
		LanguagelearningSearch.SearchBox();
	}

	@Test
	public void searchCoursePressingEnter() throws Exception{
		logger = report.createTest("Search Course Pressing Enter");
		LanguagelearningSearch.searchLanguageLearning();
		Assert.assertEquals(driver.getTitle(), "Top Language Learning Courses - Learn Language Learning Online | Coursera");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}
}
