package testCases.HeaderView;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HeaderView;
import pages.HomePage;
import utilities.Base;
import utilities.ReadExcelfile;

public class HeaderViewTest extends Base {

	HeaderView headerView=new HeaderView();
	HomePage home=new HomePage();
	String sheetName="HeaderSheet";
	public HeaderViewTest() {

		super();
	}
	@BeforeTest
	public void invokeBrowser() {
		logger = report.createTest("Checking Header View");
        setupBrowser();
		reportPass("Browser is Invoked");
		openURL();
		home.login();
	}

	@DataProvider
	public Object[][] getSheetData1() {

		Object data[][] = ReadExcelfile.getTestData(sheetName);
		return data;
	}

	
	@Test(priority = 0, dataProvider = "getSheetData1", groups = "Regression")
	public void testCases(String heading1,String heading2,String heading3,String heading4){

		headerView.cultureDropDown(heading1,heading2,heading3,heading4);
	}

	@AfterTest
	public void closebrowser() {
		reportPass("Browser is closed successfuly");
		endReport();
		closeBrowser();
	}
}
