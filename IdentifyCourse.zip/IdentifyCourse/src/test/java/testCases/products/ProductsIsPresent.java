package testCases.products;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.Enterprise;
import pages.ProductsHome;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class ProductsIsPresent extends DriverSetup {
	ProductsHome products;
	Enterprise enterprise;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;

	
	public ProductsIsPresent(){
		super();
	}

	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		products=new ProductsHome();
		enterprise=new Enterprise();
		enterprise.navigateToForEnterprise();

	}
	
	//Check for products
	@Test
	public void checkForProducts(){
		logger = report.createTest("Check for products");
		boolean flag1 = products.checkForProducts();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Assert.assertTrue(flag1);
		System.out.println("Products is displayed");
	}
	
	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}
}
