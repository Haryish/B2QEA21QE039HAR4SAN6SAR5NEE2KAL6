package testCases.enterprise;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.Enterprise;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class ForEnterpriseLink extends DriverSetup{
	Enterprise enterprise;
	protected ExtentReports report=ExtentReportManager.getReportInstance();
	protected ExtentTest logger;



	public ForEnterpriseLink(){
		super();
	}

	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		enterprise=new Enterprise();

	}
	
	//Click on ForEnterprise
	@Test
	public void ClickForEnterprise(){
		logger = report.createTest("Click For Enterprise linkedText");
		enterprise.navigateToForEnterprise();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	
	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}
}
