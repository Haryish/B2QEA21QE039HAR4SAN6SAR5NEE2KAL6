package testCases.searchCourse;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.SearchCourse;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class SearchboxIsDisplayedTest extends DriverSetup{

	SearchCourse searchCourse;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;

	public SearchboxIsDisplayedTest() {

		super();
	}

	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		searchCourse = new SearchCourse();
		searchCourse.clickBtn();
	}

	//To check is search Box Displayed
	@Test
	public void searchBoxDisplayed() {
		logger = report.createTest("To check is search Box Displayed");
		boolean flag1 = searchCourse.performOpertaion();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertTrue(flag1);
		System.out.println("Search Box is displayed");
	}

	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}
}