package pages;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.DriverSetup;
import utilities.ScreenShots;

public class Enterprise extends DriverSetup {

	Logger log = Logger.getLogger(Enterprise.class);
	@FindBy(xpath = "//a[@id='enterprise-link']")
	WebElement forEnterpriseLink;
	ScreenShots s=new ScreenShots(driver);

	// Initializing the pageobjects
	public Enterprise() {

		PageFactory.initElements(driver, this);
	}

	//Navigate to ForEnterprise 
	public void navigateToforEnterprise() {

		forEnterpriseLink.click();
	}
	
	//Check for ForEnterprise 
	public boolean checkForEnterprise(){
		s.captureScreenShot();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		log.info("Checked if FOrEnterprise is done");
		return forEnterpriseLink.isDisplayed();

	}


	//Navigate to ForEnterprise 
	public ProductsHome navigateToForEnterprise() {

		forEnterpriseLink.click();
		log.info("Navigated to 'For Enterprise' webpage");
		return new ProductsHome();
	}
}
