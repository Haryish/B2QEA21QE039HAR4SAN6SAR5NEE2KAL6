package utilities;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class Base{
  
	public static WebDriverWait wait;
	public ExtentReports report = ExtentReportManager.getReportInstance();
	public static ExtentTest logger;
    public static WebDriver driver;
	
	public Base()
	{
		try {
			ReadPropertiesfile.readPropertiesFile();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	   //Setting up Browser
       public static void setupBrowser() {
		
		String browser = ReadPropertiesfile.getbrowserName();
		
		if(browser.equalsIgnoreCase("chrome")) {
			
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//drivers//chromedriver.exe");
			driver = new ChromeDriver();
		} else if(browser.equalsIgnoreCase("Firefox")) {
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"//drivers//geckodriver.exe");
			driver = new FirefoxDriver();
		}
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
	}
	// To open the Main Page URL
		public static void openURL() {
			driver.get(ReadPropertiesfile.getUrl());
		}

		// Function to show the failed test cases in the report
		public void reportFail(String report) {
			logger.log(Status.FAIL, report);
		}

		// Function to show the passed test cases in the report
		public void reportPass(String report) {
			logger.log(Status.PASS, report);
		}

		
		public void wait(int sec, By locator) {
			wait = new WebDriverWait(driver, sec);
			wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		}

		// To input all data to the report
		public void endReport() {
			report.flush();
		}
		
		// To close the Browser
		public void closeBrowser(){
			driver.quit();
		}
}

