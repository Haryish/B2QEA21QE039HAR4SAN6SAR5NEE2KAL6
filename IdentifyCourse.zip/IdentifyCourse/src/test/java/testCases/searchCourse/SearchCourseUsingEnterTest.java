package testCases.searchCourse;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.SearchCourse;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class SearchCourseUsingEnterTest extends DriverSetup {

    SearchCourse searchCourse;
    protected ExtentReports report=ExtentReportManager.getReportInstance();
	protected ExtentTest logger;
	
	public SearchCourseUsingEnterTest() {
		
		super();
	}
	    
	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		searchCourse = new SearchCourse();
		searchCourse.clickBtn();
	}
	
	//Searching by enter tab
	@Test
	public void searchCoursePressingEnter() {
		logger = report.createTest("Searching by enter tab");
		searchCourse.searchingCourseEnter();
		Assert.assertEquals(driver.getTitle(), "Top Web Development Course Courses - Learn Web Development Course Online | Coursera");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}
	
	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}
}
