package testCases.levelFilter;



import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.languagelearningSearch;
import pages.levelFilter;
import utilities.DriverSetup;
import utilities.ExtentReportManager;



public class IsFilterClickableTest extends DriverSetup{



	levelFilter LevelFilter;
	languagelearningSearch LanguagelearningSearch;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;

	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		LevelFilter = new levelFilter();
		LanguagelearningSearch =new languagelearningSearch();
		LevelFilter = LanguagelearningSearch.Searchbox();
	}

	@Test
	public void levelFilterClickable() {
		logger = report.createTest("Level Filter clickability");

		driver.findElement(By.xpath("//*[@id='main']/div/div[2]/div/div[2]/div[2]/div/div[1]/div/span")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}

}