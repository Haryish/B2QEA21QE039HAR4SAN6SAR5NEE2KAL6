package testCases.levelFilter;



import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.languagelearningSearch;
import pages.levelFilter;
import utilities.DriverSetup;
import utilities.ExtentReportManager;



public class ExtractLevelTest extends DriverSetup{


	levelFilter LevelFilter;
	languagelearningSearch LanguagelearningSearch;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;

	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		LevelFilter = new levelFilter();
		LanguagelearningSearch =new languagelearningSearch();
		LevelFilter = LanguagelearningSearch.Searchbox();
	}


	
	@Test
	public void extractLevel() {
		logger = report.createTest("Level Extraction");

		levelFilter.availabelLevels();
	}

	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}

}