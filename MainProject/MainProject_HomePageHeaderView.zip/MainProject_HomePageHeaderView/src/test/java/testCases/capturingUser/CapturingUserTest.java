package testCases.capturingUser;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pages.HomePage;
import utilities.Base;

public class CapturingUserTest extends Base {

	
	HomePage home=new HomePage();
	public CapturingUserTest() {

		super();
	}
	@BeforeTest
	public void invokeBrowser() {
		logger = report.createTest("Login into Becognizant.");
        setupBrowser();
		reportPass("Browser is Invoked");
	}

	@Test(priority = 1)
	public void testCases() throws InterruptedException, IOException {

		openURL();
		home.login();
		home.homePage();
	}

	@AfterTest
	public void closebrowser() {
		reportPass("Browser is closed successfuly");
		endReport();
		closeBrowser();
	}
}
