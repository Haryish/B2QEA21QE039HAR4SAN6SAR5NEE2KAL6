package testCases.enterprise;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.Enterprise;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class ForEnterprisePresent extends DriverSetup {
	Enterprise enterprise;
	protected ExtentReports report=ExtentReportManager.getReportInstance();
	protected ExtentTest logger;

	public ForEnterprisePresent(){
		super();
	}

	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		enterprise=new Enterprise();
	}
	
	//Check for ForEnterprise
	@Test
	public void checkForEnterprise(){
		boolean flag1 = enterprise.checkForEnterprise();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertTrue(flag1);
		System.out.println("For Enterprise is displayed");
	}
	@AfterClass
	public void tearDown() {
		driver.quit();
	}
}
