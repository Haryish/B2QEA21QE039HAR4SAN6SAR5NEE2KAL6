package testCases.languagelearningSearch;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.languagelearningSearch;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class NavigationTest extends DriverSetup {
	
	languagelearningSearch LanguagelearningSearch;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;

	
	public NavigationTest() {
		super();
	}

	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		LanguagelearningSearch = new languagelearningSearch();
		LanguagelearningSearch.SearchBox();
	}

		@Test
		public void Navigateback() {
			logger = report.createTest("Navigation Functionality");
			LanguagelearningSearch.navigate();
		
	}
		@AfterClass
		public void tearDown() {
			driver.quit();
			report.flush();
		}

}
