package pages;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import utilities.DriverSetup;
import utilities.ScreenShots;

public class FilterCourse extends DriverSetup {
	Logger log = Logger.getLogger(ExtractWebDevelopmentCourses.class);
	// Page Objects

	@FindBy(xpath = "//body/div[@id='rendered-content']/div[1]/div[1]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]") // div[contains(text(),'Language')]
	static
	WebElement selectlang;

	@FindBy(xpath = "//div[@id='react-select-2--option-0']//div//button")
	WebElement selectEnglish;

	@FindBy(xpath = "//div[contains(text(),'Level')]")
	static
	WebElement selectLevel;

	@FindBy(xpath = "//div[@id='react-select-3--option-1']//div//button")
	WebElement selectBeginner;

	@FindBy(xpath = "//*[@id=\"react-select-8--value\"]/div[1]")
	static
	WebElement selectProduct;

	@FindBy(xpath = "//*[@id=\"react-select-8--option-1\"]/div/button/label/input")
	WebElement selectCourses;

	@FindBy(xpath="//*[@id=\"main\"]/div/div/div[1]/div/div[2]/div/div/div/div/ul/li[1]/div/div/a/div/div[2]/h2")
	public static
	WebElement coursename;

	@FindBy(xpath="/html/body/div[3]/div/div/main/div/div[2]/div/div/div/div[2]/div/div/div[5]/div[2]/div[1]")
	public static
	WebElement checklanguage;

	@FindBy(xpath="//*[@id=\"main\"]/div/div/div[1]/div/div[2]/div/div/div/div/ul/li[1]/div/div/a/div/div[2]/div[3]/div[2]/div/div[2]/span")
	WebElement checklevel;

	@FindBy(xpath="//*[@id=\"main\"]/div/div/div[1]/div/div[2]/div/div/div/div/ul/li[1]/div/div/a/div/div[2]/div[2]/div/div/span")
	WebElement checkProduct;

	ScreenShots s=new ScreenShots(driver);

	public FilterCourse() {

		PageFactory.initElements(driver, this);
	}

	//Selects the language filter option
	public void selectLanguage() {

		selectlang.click();
		//s.captureScreenShot();
		selectEnglish.click();
		log.info("Language Selected as English");
	}

	//To check language fliter is enabled
	public static boolean clickLanguage() {

		return selectlang.isEnabled();
	}

	//To check level fliter is enabled
	public static boolean clickLevel() {

		return selectLevel.isEnabled();
	}

	//To check learning Product fliter is enabled
	public static boolean clickLearningProduct() {

		return selectProduct.isEnabled();
	}

	// Selects the level filter option
	public void selectLevel() {

		selectLevel.click();
		//s.captureScreenShot();
		selectBeginner.click();
		log.info("level selected as Beginners");
	}

	// Selects the product filter option
	public void selectproduct() {

		selectProduct.click();
		//s.captureScreenShot();
		selectCourses.click();
		log.info("Product Selected as Course");
	}

	//To check level fliter is applied correctly	
	public String checkbeginner(){
		return checklevel.getText();
	}

	//To check learning product fliter is applied correctly
	public String checkcourses(){
		return checkProduct.getText();
	}

	// Actions
	public ExtractWebDevelopmentCourses selectedfliterCourses() {

		return new ExtractWebDevelopmentCourses();
	}
}
