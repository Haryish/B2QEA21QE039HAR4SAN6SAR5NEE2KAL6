package testCases.products;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.Enterprise;
import pages.ProductsHome;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class ProductsDropdown extends DriverSetup{

	ProductsHome products;
	Enterprise enterprise;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;

	public ProductsDropdown(){
		super();
	}
	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		products=new ProductsHome();
		enterprise = new Enterprise();
		enterprise.navigateToForEnterprise();

	}

	//Check dropdown under Products
	@Test
	public void checkDropdown(){
		logger = report.createTest("Check dropdown under Products");
		boolean flag1 = products.checkDropdown();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		Assert.assertTrue(flag1);
		System.out.println("Dropdown is displayed");

	}

	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}
}
