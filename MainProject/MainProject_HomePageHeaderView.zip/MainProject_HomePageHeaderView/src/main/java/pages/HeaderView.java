package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import utilities.Base;
import utilities.ScreenShots;

public class HeaderView extends Base {

	By header = By.xpath(
			"/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[2]/ul/li/button");
	By title = By.className("workspaces__title");
	//Culture
	By aboutCognizantdetail = By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[1]/div/div/div/div/div[2]/div/nav/div[1]/div[3]/div/div[1]/ul/li/a");
	By Strategydetail = By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[1]/div/div/div/div/div[2]/div/nav/div[2]/div[3]/div/div[1]/ul/li/a");
	By Inclusivedetail = By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[1]/div/div/div/div/div[2]/div/nav/div[3]/div[3]/div/div[1]/ul/li/a");
	By aboutCognizantCount = By
			.xpath("//*[@id=\"983466WorkspaceCollapseMenu\"]/div/div/div/div[2]/div/nav/div[1]/div[1]/span[2]");
	By StrategyCount = By
			.xpath("//*[@id='983466WorkspaceCollapseMenu']/div/div/div/div[2]/div/nav/div[2]/div[1]/span[2]");
	By InclusiveCount = By
			.xpath("//*[@id='983466WorkspaceCollapseMenu']/div/div/div/div[2]/div/nav/div[3]/div[1]/span[2]");
    //Pratice and Markets
	By praticeMarketstitle=By.xpath("//*[@id=\"983464WorkspaceCollapseMenu\"]/div/div/div/div[2]/div/nav/div/div[2]");
	By praticesdetail=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[2]/div/div/div/div/div[2]/div/nav/div[1]/div[3]/div/div[1]/ul/li/a");
	By marketdetail=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[2]/div/div/div/div/div[2]/div/nav/div[2]/div[3]/div/div[1]/ul/li/a");
    By crossfundetail=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[2]/div/div/div/div/div[2]/div/nav/div[3]/div[3]/div/div[1]/ul/li/a");
    By praticescount=By.xpath("//*[@id=\"983464WorkspaceCollapseMenu\"]/div/div/div/div[2]/div/nav/div[1]/div[1]/span[2]");
    By marketcount=By.xpath("//*[@id='983464WorkspaceCollapseMenu']/div/div/div/div[2]/div/nav/div[2]/div[1]/span[2]");
    By crossfuncount=By.xpath("//*[@id='983464WorkspaceCollapseMenu']/div/div/div/div[2]/div/nav/div[3]/div[1]/span[2]");
	
    //Corporate Functions
     By corporatetitle=By.xpath("//*[@id=\"983462WorkspaceCollapseMenu\"]/div/div/div/div[2]/div/nav/div/div[2]");
     By financedetails=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[3]/div/div/div/div/div[2]/div/nav/div[1]/div[3]/div/div[1]/ul/li/a");
     By marketingdetail=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[3]/div/div/div/div/div[2]/div/nav/div[2]/div[3]/div/div[1]/ul/li/a");
     By administrationdetail=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[3]/div/div/div/div/div[2]/div/nav/div[3]/div[3]/div/div[1]/ul/li/a");
     By legaldetail=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[3]/div/div/div/div/div[2]/div/nav/div[4]/div[3]/div/div[1]/ul/li/a");
     By techldetail=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[3]/div/div/div/div/div[2]/div/nav/div[5]/div[3]/div/div[1]/ul/li/a");
     By financeCount=By.xpath("//*[@id=\"983462WorkspaceCollapseMenu\"]/div/div/div/div[2]/div/nav/div[1]/div[1]/span[2]");
     By marketingCount=By.xpath("//*[@id=\"983462WorkspaceCollapseMenu\"]/div/div/div/div[2]/div/nav/div[2]/div[1]/span[2]");
     By administrationCount=By.xpath("//*[@id=\"983462WorkspaceCollapseMenu\"]/div/div/div/div[2]/div/nav/div[3]/div[1]/span[2]");
     By legalCount=By.xpath("//*[@id=\"983462WorkspaceCollapseMenu\"]/div/div/div/div[2]/div/nav/div[4]/div[1]/span[2]");
     By techCount=By.xpath("//*[@id=\"983462WorkspaceCollapseMenu\"]/div/div/div/div[2]/div/nav/div[5]/div[1]/span[2]");
     
     //Associate Resources
     By associatetitle=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[4]/div/div/div/div/div[2]/div/nav/div/div[2]");
     By global=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[4]/div/div/div/div/div[2]/div/nav/div[1]/div[3]/div/div[1]/ul/li/a");
     By career=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[4]/div/div/div/div/div[2]/div/nav/div[2]/div[3]/div/div[1]/ul/li/a");
     By learning=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[4]/div/div/div/div/div[2]/div/nav/div[3]/div[3]/div/div[1]/ul/li/a");
     By life=By.xpath("/html/body/div/app-root/unily-header/dynamic-content-viewer/upgrade-component-wrapper/div/header/div[3]/div[4]/div/div/div/div/div[2]/div/nav/div[4]/div[3]/div/div[1]/ul/li/a");
     By globalCount=By.xpath("//*[@id='983458WorkspaceCollapseMenu']/div/div/div/div[2]/div/nav/div[1]/div[1]/span[2]");
     By careerCount=By.xpath("//*[@id='983458WorkspaceCollapseMenu']/div/div/div/div[2]/div/nav/div[2]/div[1]/span[2]");
     By learningCount=By.xpath("//*[@id=\"983458WorkspaceCollapseMenu\"]/div/div/div/div[2]/div/nav/div[3]/div[1]/span[2]");
     By lifeCount=By.xpath("//*[@id='983458WorkspaceCollapseMenu']/div/div/div/div[2]/div/nav/div[4]/div[1]/span[2]");
     /*
	 * By detail=By.className("workspacelink"); By
	 * wrkcount=By.className("workspaces__count");
	 */

	// Initializing the Page Object
	public HeaderView() {

		PageFactory.initElements(driver, this);
	}

	public void cultureDropDown(String heading1,String heading2,String heading3,String heading4) {
		ScreenShots s=new ScreenShots(driver);
		List<WebElement> headers = driver.findElements(header);
		for (WebElement n : headers) {
			// driver.findElement(culture).click();
			//n.click();
			if (n.getText().contentEquals(heading1)) {
				n.click();
				
				reportPass("Culture is clicked");
				System.out.println("Culture is clicked");
				s.captureScreenShot();
				List<WebElement> titles = driver.findElements(title);
				for (WebElement tit : titles) {
					if (tit.getText().isEmpty()) {
						break;
					} else {
						System.out.println("\n" + tit.getText());
						if (tit.getText().contentEquals("About Cognizant")) {
							List<WebElement> details = driver.findElements(aboutCognizantdetail);
							int count = 0;
							count = details.size();
							System.out.println("Count:" + count);
							for (WebElement d : details) {
								System.out.println(d.getText());
							}
							String actualcount = driver.findElement(aboutCognizantCount).getText();
							//System.out.println(actualcount);
							int acount = Integer.parseInt(actualcount);
							if (acount == count) {
								reportPass("About Cognizant Count verified");
								System.out.println("Matched");
							} else {
								reportFail("About Cognizant count is not correct");
								System.out.println("Mismatched");
							}
						} else if (tit.getText().contentEquals("Strategy and Latest Thinking")) {
							List<WebElement> details = driver.findElements(Strategydetail);
							int count = 0;
							count = details.size();
							System.out.println("Count:" + count);
							for (WebElement d : details) {
								System.out.println(d.getText());
							}
							String actualcount = driver.findElement(StrategyCount).getText();
							//System.out.println(actualcount);
							int acount = Integer.parseInt(actualcount);
							if (acount == count) {
								reportPass("Strategy and Latest Thinking Count verified");
								System.out.println("Matched");
							} else {
								reportFail("Strategy and Latest Thinking count is not correct");
								System.out.println("Mismatched");
							}
						} else if (tit.getText().contentEquals("Inclusion and Values")) {
							List<WebElement> details = driver.findElements(Inclusivedetail);
							int count = 0;
							count = details.size();
							System.out.println("Count:" + count);
							for (WebElement d : details) {
								System.out.println(d.getText());
							}
							String actualcount = driver.findElement(InclusiveCount).getText();
							//System.out.println(actualcount);
							int acount = Integer.parseInt(actualcount);
							if (acount == count) {
								reportPass("Inclusion and Values Count verified");
								System.out.println("Matched");
							} else {
								reportFail("Inclusion and Values count is not correct");
								System.out.println("Mismatched");
							}
						}

					}
				}
			}else if(n.getText().contentEquals(heading2)){
				n.click();
				
				reportPass("Practices & Markets is clicked");
				System.out.println("\n\nPractices & Markets is clicked");
				s.captureScreenShot();
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				List<WebElement> titles = driver.findElements(praticeMarketstitle);
				for (WebElement tit : titles) {

					if (tit.getText().isEmpty()) {
						break;
					} else {
						System.out.println("\n" + tit.getText());
						if (tit.getText().contentEquals("Practices")) {
							List<WebElement> detailss = driver.findElements(praticesdetail);
							int count;
							count = detailss.size();
							System.out.println("Count:" + count);
							for (WebElement d : detailss) {
								System.out.println(d.getText());
							}
							String actualcount = driver.findElement(praticescount).getText();
							//System.out.println(actualcount);
							int acount = Integer.parseInt(actualcount);
							if (acount == count) {
								reportPass("Pratice Count verified");
								System.out.println("Matched");
							} else {
								reportFail("Pratice count is not correct");
								System.out.println("Mismatched");
							}
						} else if (tit.getText().contentEquals("Markets")) {
							List<WebElement> details = driver.findElements(marketdetail);
							int count = 0;
							count = details.size();
							System.out.println("Count:" + count);
							for (WebElement d : details) {
								System.out.println(d.getText());
							}
							String actualcount = driver.findElement(marketcount).getText();
							//System.out.println(actualcount);
							int acount = Integer.parseInt(actualcount);
							if (acount == count) {
								reportPass("Markets Count verified");
								System.out.println("Matched");
							} else {
								reportFail("Markets count is not correct");
								System.out.println("Mismatched");
							}
						} else if (tit.getText().contentEquals("Cross-Functional Groups")) {
							List<WebElement> details = driver.findElements(crossfundetail);
							int count = 0;
							count = details.size();
							System.out.println("Count:" + count);
							for (WebElement d : details) {
								System.out.println(d.getText());
							}
							String actualcount = driver.findElement(crossfuncount).getText();
							//System.out.println(actualcount);
							int acount = Integer.parseInt(actualcount);
							if (acount == count) {
								reportPass("Cross-Functional Groups Count verified");
								System.out.println("Matched");
							} else {
								reportFail("Cross-Functional Groups count is not correct");
								System.out.println("Mismatched");
							}
						}

					}
			}
		}else if(n.getText().contentEquals(heading3)){
			n.click();
			
			reportPass("Corporate Functions is clicked");
			System.out.println("\n\nCorporate Functions is clicked");
			s.captureScreenShot();
			List<WebElement> titles = driver.findElements(corporatetitle);
			for (WebElement tit : titles) {

				if (tit.getText().isEmpty()) {
					break;
				} else {
					System.out.println("\n" + tit.getText());
					if (tit.getText().contentEquals("Finance")) {
						List<WebElement> detailss = driver.findElements(financedetails);
						int count;
						count = detailss.size();
						System.out.println("Count:" + count);
						for (WebElement d : detailss) {
							System.out.println(d.getText());
						}
						String actualcount = driver.findElement(financeCount).getText();
						//System.out.println(actualcount);
						int acount = Integer.parseInt(actualcount);
						if (acount == count) {
							reportPass("Finance Count verified");
							System.out.println("Matched");
						} else {
							reportFail("Finance count is not correct");
							System.out.println("Mismatched");
						}
					} else if (tit.getText().contentEquals("Marketing")) {
						List<WebElement> details = driver.findElements(marketingdetail);
						int count = 0;
						count = details.size();
						System.out.println("Count:" + count);
						for (WebElement d : details) {
							System.out.println(d.getText());
						}
						String actualcount = driver.findElement(marketingCount).getText();
						//System.out.println(actualcount);
						int acount = Integer.parseInt(actualcount);
						if (acount == count) {
							reportPass("Marketing Count verified");
							System.out.println("Matched");
						} else {
							reportFail("Marketing count is not correct");
							System.out.println("Mismatched");
						}
					} else if (tit.getText().contentEquals("Administration")) {
						List<WebElement> details = driver.findElements(administrationdetail);
						int count = 0;
						count = details.size();
						System.out.println("Count:" + count);
						for (WebElement d : details) {
							System.out.println(d.getText());
						}
						String actualcount = driver.findElement(administrationCount).getText();
						//System.out.println(actualcount);
						int acount = Integer.parseInt(actualcount);
						if (acount == count) {
							reportPass("Administration Count verified");
							System.out.println("Matched");
						} else {
							reportFail("Administration count is not correct");
							System.out.println("Mismatched");
						}
					}else if (tit.getText().contentEquals("Legal")) {
						List<WebElement> details = driver.findElements(legaldetail);
						int count = 0;
						count = details.size();
						System.out.println("Count:" + count);
						for (WebElement d : details) {
							System.out.println(d.getText());
						}
						String actualcount = driver.findElement(legalCount).getText();
						//System.out.println(actualcount);
						int acount = Integer.parseInt(actualcount);
						if (acount == count) {
							reportPass("Legal Count verified");
							System.out.println("Matched");
						} else {
							reportFail("Legal count is not correct");
							System.out.println("Mismatched");
						}
					}else if (tit.getText().contentEquals("Strategy & Technology")) {
						List<WebElement> details = driver.findElements(techldetail);
						int count = 0;
						count = details.size();
						System.out.println("Count:" + count);
						for (WebElement d : details) {
							System.out.println(d.getText());
						}
						String actualcount = driver.findElement(techCount).getText();
						//System.out.println(actualcount);
						int acount = Integer.parseInt(actualcount);
						if (acount == count) {
							reportPass("Strategy & Technology Count verified");
							System.out.println("Matched");
						} else {
							reportFail("Strategy & Technology count is not correct");
							System.out.println("Mismatched");
						}
					}

				}
		}
		}else if(n.getText().contentEquals(heading4)){
			n.click();
			
			reportPass("Associate Resources is clicked");
			System.out.println("\n\nAssociate Resources is clicked");
			s.captureScreenShot();
			List<WebElement> titles = driver.findElements(associatetitle);
			for (WebElement tit : titles) {

				if (tit.getText().isEmpty()) {
					break;
				} else {
					System.out.println("\n" + tit.getText());
					if (tit.getText().contentEquals("Global Human Resources")) {
						List<WebElement> detailss = driver.findElements(global);
						int count;
						count = detailss.size();
						System.out.println("Count:" + count);
						for (WebElement d : detailss) {
							System.out.println(d.getText());
						}
						String actualcount = driver.findElement(globalCount).getText();
						//System.out.println(actualcount);
						int acount = Integer.parseInt(actualcount);
						if (acount == count) {
							reportPass("Global Human ResourcesCount verified");
							System.out.println("Matched");
						} else {
							reportFail("Global Human Resources count is not correct");
							System.out.println("Mismatched");
						}
					} else if (tit.getText().contentEquals("Career")) {
						List<WebElement> details = driver.findElements(career);
						int count = 0;
						count = details.size();
						System.out.println("Count:" + count);
						for (WebElement d : details) {
							System.out.println(d.getText());
						}
						String actualcount = driver.findElement(careerCount).getText();
						//System.out.println(actualcount);
						int acount = Integer.parseInt(actualcount);
						if (acount == count) {
							reportPass("CareerCount verified");
							System.out.println("Matched");
						} else {
							reportFail("Career count is not correct");
							System.out.println("Mismatched");
						}
					} else if (tit.getText().contentEquals("Learning")) {
						List<WebElement> details = driver.findElements(learning);
						int count = 0;
						count = details.size();
						System.out.println("Count:" + count);
						for (WebElement d : details) {
							System.out.println(d.getText());
						}
						String actualcount = driver.findElement(learningCount).getText();
						//System.out.println(actualcount);
						int acount = Integer.parseInt(actualcount);
						if (acount == count) {
							reportPass("Learning Count verified");
							System.out.println("Matched");
						} else {
							reportFail("Learningcount is not correct");
							System.out.println("Mismatched");
						}
					}else if (tit.getText().contentEquals("Work & Life")) {
						List<WebElement> details = driver.findElements(life);
						int count = 0;
						count = details.size();
						System.out.println("Count:" + count);
						for (WebElement d : details) {
							System.out.println(d.getText());
						}
						String actualcount = driver.findElement(lifeCount).getText();
						//System.out.println(actualcount);
						int acount = Integer.parseInt(actualcount);
						if (acount == count) {
							reportPass("Work & Life Count verified");
							System.out.println("Matched");
						} else {
							reportFail("Work & Life count is not correct");
							System.out.println("Mismatched");
						}
					}

				}
		}
		}
	}
}
}
