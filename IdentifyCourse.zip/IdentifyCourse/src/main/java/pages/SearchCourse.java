
package pages;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utilities.DriverSetup;
import utilities.ReadPropertiesfile;
import utilities.ScreenShots;

public class SearchCourse extends DriverSetup {
	Logger log = Logger.getLogger(SearchCourse.class);
	@FindBy(className = "react-autosuggest__input")
	WebElement searchTextBox;

	@FindBy(xpath = "//span[contains(text(),'web development course')]")
	WebElement text;// dropdowntext

	@FindBy(xpath = "//*[@id=\"rendered-content\"]/div/header/div/div/div/div[1]/div[3]/div/form/div/div/div[1]/button[2]/div")
	static WebElement searchlogo;

	@FindBy(xpath = "//*[@id=\"main\"]/div/div/div[1]/div[1]/div/div/div/div/div/div/div[4]/div/div/div/div/div/a/div/div[2]/span[1]/span")
	WebElement course;
	
	ScreenShots s=new ScreenShots(driver);
	
	
	public SearchCourse() {
		

		PageFactory.initElements(driver, this);
	}

	//To click on searchbox
	public void clickBtn() {

		searchTextBox.click();
	}

	//to verify placeholder
	public String toCheckPlaceholder() {
        s.captureScreenShot();
		return searchTextBox.getAttribute("placeholder");
	}

	//To check searchbox is displayed or not
	public boolean performOpertaion() {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return searchTextBox.isDisplayed();
	}

	//Search Using drop down
	public void searchDropdown() {
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		text.click();
		System.out.println(text.getText());
	}

	//Search using button
	public void clicklogo() {
		searchlogo.click();
		log.info("Clicked the search Butoon");
	}

	//search by pressing enter key
	public void searchingCourseEnter() {

		searchTextBox.sendKeys(ReadPropertiesfile.getCoursename1(), Keys.ENTER);
		System.out.println(text.getText());
		s.captureScreenShot();
		log.info("Entered the search textbox. Text field functionality executed successfully.");
	}

	//Entering coursename in search tab
	public void entercourse() {
		searchTextBox.sendKeys(ReadPropertiesfile.getCoursename1());
	}

	// Actions
	public FilterCourse clickSearchbox() {

		searchTextBox.click();
		searchTextBox.sendKeys(ReadPropertiesfile.getCoursename1()+ Keys.ENTER);
		return new FilterCourse();
	}
}
