package testCases.ExtractWebDevelopmentCourse;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.ExtractWebDevelopmentCourses;
import pages.FilterCourse;
import pages.SearchCourse;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class IsRatingDisplayedTest extends DriverSetup{

	ExtractWebDevelopmentCourses extractWebCourses;
	protected ExtentReports report=ExtentReportManager.getReportInstance();
	protected ExtentTest logger;
	
	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		FilterCourse filterCourse = new FilterCourse();
		SearchCourse searchCourse=new SearchCourse();
		filterCourse = searchCourse.clickSearchbox();
		filterCourse.selectLanguage();
		filterCourse.selectLevel();
		filterCourse.selectproduct();
		extractWebCourses=filterCourse.selectedfliterCourses();
	}
	
	//Rating is displayed
	@Test
    public void IsCourseRatingDisplayed() {
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			boolean flag1=extractWebCourses.CourseRating1();
			Assert.assertTrue(flag1);
			boolean flag2=extractWebCourses.CourseRating2();
			Assert.assertTrue(flag2);
			System.out.println("Course rating is displayed");
		    
	}
	

	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}
