package testCases.products;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.Enterprise;
import pages.ProductsHome;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class ForCampusLink extends DriverSetup {

	ProductsHome products;
	Enterprise enterprise;
	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;

	public ForCampusLink (){
		super();
	}
	@BeforeClass
	public void openBrowser() {
		setupBrowser();
		products=new ProductsHome();
		enterprise = new Enterprise();
		enterprise.navigateToForEnterprise();
		products.checkDropdown();
	}
    
	//Click on ForCampus
	@Test
	public void selectForCampus(){
		logger = report.createTest("Click on ForCampus");

		products.clickonForCampus();
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		String parentWindow = driver.getWindowHandle();
		//WebDriverWait wait = new WebDriverWait(driver, 20);

		//wait.until(ExpectedConditions.elementToBeClickable(FilterCourse.coursename));

		Set<String> handles1 = driver.getWindowHandles();
		Iterator<String> itr1 = handles1.iterator();
		while(itr1.hasNext()) {

			String childWindow1 = itr1.next();
			if (!childWindow1.contentEquals(parentWindow)) {
				driver.switchTo().window(childWindow1);
				Assert.assertEquals(driver.getTitle(),"Coursera for Campus | Online Learning Platform for Universities");

			}
		}
	}
	@AfterClass
	public void tearDown() {
		driver.quit();
		report.flush();
	}
}
