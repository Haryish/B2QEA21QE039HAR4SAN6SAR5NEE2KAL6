package testCases.searchCourse;

import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.SearchCourse;
import utilities.DriverSetup;
import utilities.ExtentReportManager;

public class SearchCourseUsingDropdown extends DriverSetup{


	 SearchCourse searchCourse;
	 protected ExtentReports report = ExtentReportManager.getReportInstance();
	 protected ExtentTest logger;
		
		public SearchCourseUsingDropdown() {
			
			super();
		}
		    
		@BeforeClass
		public void openBrowser() {
			setupBrowser();
			searchCourse = new SearchCourse();
			searchCourse.clickBtn();
		}
		
		//Searching by selecting from dropdown
		@Test
		public void searchCourseUsingDropdown() {
			logger = report.createTest("Searching by selecting from dropdown");
			searchCourse.entercourse();
			searchCourse.searchDropdown();
			Assert.assertEquals(driver.getTitle(), "Top Web Development Course Courses - Learn Web Development Course Online | Coursera");
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		}
		
		@AfterClass
		public void tearDown() {
			report.flush();
			driver.quit();
		}
}
