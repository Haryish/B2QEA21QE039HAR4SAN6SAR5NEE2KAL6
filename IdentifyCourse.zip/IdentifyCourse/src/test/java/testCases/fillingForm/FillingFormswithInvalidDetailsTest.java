package testCases.fillingForm;


import java.util.Iterator;
import java.util.Set;

import org.testng.Assert;
//import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import pages.Enterprise;
import pages.FillingForm;
import pages.ProductsHome;
import utilities.DriverSetup;
import utilities.ExtentReportManager;
import utilities.ReadExcelfile;

public class FillingFormswithInvalidDetailsTest extends DriverSetup {


	protected ExtentReports report = ExtentReportManager.getReportInstance();
	protected ExtentTest logger;
	String parentWindow;
	ProductsHome productsHome;
	FillingForm fillingForm;

    String sheetName1="FirstPage";
	String sheetName2 = "SecondPage";

	public FillingFormswithInvalidDetailsTest() {
		super();
	}

	@BeforeClass
	public void setUp() {

		setupBrowser();
		Enterprise enterprise=new Enterprise();
		productsHome=enterprise.navigateToForEnterprise();
		fillingForm=productsHome.navigateToFillingForm();

	}

   @DataProvider
	public Object[][] getSixthPageData() {

		Object data[][] = ReadExcelfile.getTestData(sheetName2);
		return data;
	}

	@Test(priority = 0, dataProvider = "getSixthPageData", groups = "Regression")
	public void fillingWithoutEmail(String Fname, String Lname, String JFunc, String JTitle, String Instiname,
			String Institype, String disp, String country) {
		System.out.println(Fname+Lname+JFunc);
		logger = report.createTest("Test with Invalid Data to the form");

		parentWindow = driver.getWindowHandle();
		fillingForm.clickonForCampus();
		Set<String> handles = driver.getWindowHandles();
		Iterator<String> itr = handles.iterator();
		while (itr.hasNext()) {

			String childWindow1 = itr.next();
			if (!childWindow1.contentEquals(parentWindow)) {
				driver.switchTo().window(childWindow1);
				fillingForm.clickGetStarted();
				try {

					Thread.sleep(1000);
					fillingForm.execelInvalidEmail(Fname, Lname, JFunc, JTitle, Instiname, Institype, disp, country);

					Thread.sleep(2000);
					boolean flag = fillingForm.emailErrorDisplayed();
					Assert.assertTrue(flag);
				} catch (Exception e) {
					e.printStackTrace();
				}
				driver.close();
			}
			driver.switchTo().window(parentWindow);
		}
	}
	
	@AfterClass
	public void tearDown() {
		report.flush();
		driver.quit();
	}
}