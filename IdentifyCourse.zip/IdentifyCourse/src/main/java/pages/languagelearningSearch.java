package pages;


import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.DriverSetup;
import utilities.ReadPropertiesfile;
import utilities.ScreenShots;

public class languagelearningSearch extends DriverSetup{
	Logger log = Logger.getLogger(languagelearningSearch.class);
	WebDriverWait wait = new WebDriverWait(driver, 40);
	ScreenShots s=new ScreenShots(driver);

	@FindBy(xpath = "//input[@placeholder='What do you want to learn?']")
	WebElement searchBox;

	@FindBy(xpath = "//button[@class='nostyle search-button']//div[@class='magnifier-wrapper'] ")
	WebElement searchIcon;
	
	
	public void navigate() {
		
		driver.navigate().back();
		
	}
	
	public languagelearningSearch()
	{
		PageFactory.initElements(driver, this);
	}

	public void SearchBox() {
		// TODO Auto-generated method stub
		searchBox.click();
	}

	public void searchLanguageLearning()
	{
	
		searchBox.sendKeys(ReadPropertiesfile.getCoursename2());
		searchIcon.click();
		s.captureScreenShot();
	}



	public languageFilter clickSearchbox() {

		searchBox.click();
		searchBox.sendKeys("Language learning" + Keys.ENTER);
		log.info("Searching Language Learning courses");
		return new languageFilter();
		
	}
	
	public levelFilter Searchbox() {

		searchBox.click();
		searchBox.sendKeys("Language learning" + Keys.ENTER);
		log.info("Level filter is Executing for next step");
		return new levelFilter();
	}
	


}
