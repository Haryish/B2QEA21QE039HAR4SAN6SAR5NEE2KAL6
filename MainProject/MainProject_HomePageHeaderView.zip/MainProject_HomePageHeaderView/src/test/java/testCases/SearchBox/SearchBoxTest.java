package testCases.SearchBox;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.SearchBox;
import utilities.Base;
import utilities.ReadExcelfile;

public class SearchBoxTest extends Base{
   
	HomePage home=new HomePage();
	SearchBox box=new SearchBox();
	String sheetName="SearchSheet";
	public SearchBoxTest() {

		super();
	}
	@BeforeTest
	public void invokeBrowser() {
		logger = report.createTest("Search in Workspace");
        setupBrowser();
		reportPass("Browser is Invoked");
		openURL();
		home.login();
	}

	@DataProvider
	public Object[][] getSheetData() {

		Object data[][] = ReadExcelfile.getTestData(sheetName);
		return data;
	}

	
	@Test(priority = 0, dataProvider = "getSheetData", groups = "Regression")
	public void testCases(String heading,String elementTobeSearched){

		box.searchBox(heading, elementTobeSearched);
	}

	@AfterTest
	public void closebrowser() {
		reportPass("Browser is closed successfuly");
		endReport();
		closeBrowser();
	}
}
