package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import utilities.Base;
import utilities.ReadPropertiesfile;
import utilities.ScreenShots;

public class HomePage extends Base {
	
	By email=By.xpath("//input[@type='email']");
	By next=By.xpath("//input[@type='submit']");
	By pass=By.name("passwd");
	By yes=By.xpath("//input[@value='Yes']");
	By usname=By.id("user-name");
	public void homePage()
	{
		ScreenShots s=new ScreenShots(driver);
		s.captureScreenShot();
		//printing user name
				WebElement uname=driver.findElement(usname);
				String Username=uname.getText().replace("(Cognizant)","");
				System.out.println("UserName:"+Username);
		
	}
	public void login()
	{
		
		try
		{
		
		wait(20,email);
		driver.findElement(email).sendKeys(ReadPropertiesfile.getEmail());
		driver.findElement(next).click();
		wait(20,pass);
		driver.findElement(pass).sendKeys(ReadPropertiesfile.getPassword());
		driver.findElement(next).click();
		Thread.sleep(1000);
		reportPass("Email and Password Verified sucessfully");
		wait(120,yes);
		driver.findElement(yes).click();
				//Verify Title
				if (driver.getTitle().contains("Be.Cognizant"))
					// Pass
					System.out.println("Page title contains Be.Cognizant");
				else
					// Fail
					System.out.println("Page title doesn't contains Be.Cognizant");
				
				reportPass("Be.Cognizant Page is reached sucessfully");
				
				} catch (Exception e) {
					reportFail(e.getMessage());
				}
	}
}

