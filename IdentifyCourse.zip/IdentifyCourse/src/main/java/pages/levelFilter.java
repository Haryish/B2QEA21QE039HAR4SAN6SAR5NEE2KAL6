package pages;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.DriverSetup;

public class levelFilter extends DriverSetup{
	Logger log = Logger.getLogger(levelFilter.class);
	static WebDriverWait wait = new WebDriverWait(driver, 40);
	
	@FindBy(xpath = "//a[contains(text(),'✕')]")
	public static WebElement cross;

	@FindBy(xpath = "//div[contains(text(),'Level')]")
	public static
	WebElement selectLevelFilter;

	@FindBy(xpath="/html[1]/body[1]/div[3]/div[1]/div[1]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[3]/div[1]/div[3]/div[2]")
	Select languageFilterOptions;
	
	public static void availabelLevels() {
		
	try {
			driver.findElement(By.xpath("//div[contains(text(),'Level')]")).click();
		    By name = By.className("_htmk7zm");
			List <WebElement> levelname = driver.findElements(name);
			//Select s = new Select(driver.findElement(By.xpath("//div[contains(text(),'Level')]")));
			//List<WebElement> e = s.getOptions();
			int itemCount = levelname.size();
		
			for(int i = 0; i < itemCount; i++)
			{

				System.out.println(levelname.get(i).getAttribute("value"));
				}
			System.out.println("Count: "+itemCount);
	}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}


