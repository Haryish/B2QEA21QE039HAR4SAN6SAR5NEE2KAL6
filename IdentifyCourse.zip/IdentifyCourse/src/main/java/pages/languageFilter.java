package pages;


import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.DriverSetup;
import utilities.ScreenShots;

public class languageFilter extends DriverSetup {
	Logger log = Logger.getLogger(languageFilter.class);
	static WebDriverWait wait = new WebDriverWait(driver, 40);
	
	//@FindBy(xpath = "//*[@id=\"react-select-2--value\"]/div[1]")
	//public static WebElement selectLanguageFilter;

	@FindBy(xpath = "//*[@class='update-refinements' and contains(text(),'Show All')]")
	public static WebElement showAll;

	@FindBy(xpath = "//a[contains(text(),'✕')]")
	public static WebElement cross;
	
	public static void availabelLanguages()
	{



		try {
	
			driver.findElement(By.xpath("/html/body/div[3]/div/div/main/div/div/div[1]/div/div[1]/div/div[2]/div/div[2]/div[1]/div/div[1]/div/div/div[1]")).click();
			//showAll.click();
			driver.findElement(By.xpath("//*[@class='update-refinements' and contains(text(),'Show All')]")).click();
            ScreenShots s=new ScreenShots(driver);
            s.captureScreenShot();
				        driver.switchTo().parentFrame();
						 By lanname = By.className("_htmk7zm");
							List <WebElement> languagenames= driver.findElements(lanname);
							int languageCount=languagenames.size();
							System.out.println("Language Count:"+languageCount);
							for(int i = 0; i < languageCount; i++)
							{
								System.out.println(languagenames.get(i).getAttribute("value"));
								}
				

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
